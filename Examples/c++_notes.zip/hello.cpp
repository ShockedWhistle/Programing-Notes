#include <iostream>

using namespace std;

int main()
{
    string charecterName = "John";
    int characterAge;
    characterAge = 70;

    cout << "Hello World!\n" 
    << "This dude named " << charecterName << endl;

    return 0;
}